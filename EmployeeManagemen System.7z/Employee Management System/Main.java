import java.util.Scanner;
import java.util.ArrayList;
class Main{
public static void main(String[] args){
    ArrayList<Employee> employees = new ArrayList<>();

    int an;// Answer question for continue
    Scanner myObj = new Scanner(System.in);
    int count = 0;// total cost for the company
int idsc;// id scanned for employee
String namesc;// name scanned for employee
int wtsc;// work type for

int sal;// salary full time job
int hw; // hours work by part time employee
int hr;// hourly rating  for part time employee
int cs;// contract salary

        System.out.println("Whelcome to salary team ");
do{
System.out.println("Enter employee id ");// get employee id
idsc = myObj.nextInt();

System.out.println("Enter employee name "); // get employee name
namesc = myObj.nextLine();
do{
System.out.println("Enter employee work type FullTime(0) or PartTime (1) Contract (2) ");// FullTime FartTime Contract
wtsc = myObj.nextInt();
}while(!(wtsc==1|| wtsc==0 || wtsc==2));
if (wtsc==0 ){
System.out.println("Give me "+namesc+" salary");
sal = myObj.nextInt();

employees.add(new FTE(idsc, "namesc Doe", sal));
}
else if(wtsc==1){
    System.out.println("Give me "+namesc+" hours work");
hw = myObj.nextInt();

System.out.println("Give me "+namesc+" hourly rate");
hr = myObj.nextInt();
employees.add(new PTE(idsc,namesc, hr, hw));
    
}
else{
    System.out.println("Give me "+namesc+" contract salary");
cs = myObj.nextInt();
employees.add(new CE(idsc, namesc, cs));
    
}

System.out.println("Employee ID: " +idsc);
System.out.println("Name: " + namesc);
System.out.println("Salary: $" + employees.Salary());
System.out.println();
do{
System.out.println("Do you want to continue YES(1) or NO(0)");
an = myObj.nextInt();

 }while(!(an==1|| an==0));

}while (an==1);
System.out.println("Total cost for the month is : "+ count);
System.out.println("Thanks for working with me");
}

}