// FullTimeEmployee
public class FTE extends Employee {
    private double MS; // Monthly Salary

    public FTE (int Id, String name, double MS) {
        super(Id, name);
        this.MS = MS;
    }

    @Override
    public double Salary() {
        return MS;
    }
}
