// ContractEmployee
public class CE extends Employee {
    private double CA;//contract amount

    public CE(int Id, String name, double CA) {
        super(Id, name);
        this.CA = CA;
    }

    @Override
    public double Salary() {
        return CA;
    }
}
