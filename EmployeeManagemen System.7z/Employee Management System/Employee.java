
public abstract class Employee {

 private static int Id;
    private String name;

    public Employee(int Id, String name) {
        Employee.Id = Id;
        this.name = name;
    }

    public static int getEmployeeId() {
        return Id;
    }

    public String getName() {
        return name;
    }

    public abstract double Salary();
}




