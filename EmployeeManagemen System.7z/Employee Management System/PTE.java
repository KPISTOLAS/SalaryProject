// PartTimeEmployee
public class PTE extends Employee {
    private double HR;//hourly rate
    private double HW;//hours worked

    public PTE(int Id, String name, double HR, double HW) {
        super(Id, name);
        this.HR = HR;
        this.HW = HW;
    }

    @Override
    public double Salary() {
        return HR * HW;
    }
}
